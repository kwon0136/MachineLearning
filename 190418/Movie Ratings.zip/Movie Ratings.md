

```R
# Download the movie ratings and IMDB movie titles from the sample datasets collection
library("AzureML")
ws <- workspace()
ratings <- download.datasets(ws, "Movie Ratings")
titles <- download.datasets(ws,"IMDB Movie Titles")
```


```R
# Examine the first few rows in each dataset
head(ratings) 
head(titles)
```


<table>
<thead><tr><th>UserId</th><th>MovieId</th><th>Rating</th><th>Timestamp</th></tr></thead>
<tbody>
	<tr><td>1         </td><td>  68646   </td><td>10        </td><td>1381620027</td></tr>
	<tr><td>1         </td><td> 113277   </td><td>10        </td><td>1379466669</td></tr>
	<tr><td>2         </td><td> 454876   </td><td> 8        </td><td>1394818630</td></tr>
	<tr><td>2         </td><td> 790636   </td><td> 7        </td><td>1389963947</td></tr>
	<tr><td>2         </td><td> 816711   </td><td> 8        </td><td>1379963769</td></tr>
	<tr><td>2         </td><td>1091191   </td><td> 7        </td><td>1391173869</td></tr>
</tbody>
</table>




<table>
<thead><tr><th>Movie.ID</th><th>Movie.Name</th></tr></thead>
<tbody>
	<tr><td>   8                                         </td><td>Edison Kinetoscopic Record of a Sneeze (1894)</td></tr>
	<tr><td>  91                                         </td><td>Le manoir du diable (1896)                   </td></tr>
	<tr><td> 417                                         </td><td>Le voyage dans la lune (1902)                </td></tr>
	<tr><td> 628                                         </td><td>The  s of Dollie (1908)                      </td></tr>
	<tr><td> 833                                         </td><td>The Country Doctor (1909)                    </td></tr>
	<tr><td>1223                                         </td><td>Frankenstein (1910)                          </td></tr>
</tbody>
</table>




```R
# Merge the two datasets over the movie id
movieData <- merge(ratings, titles, by.x = "MovieId", by.y = "Movie.ID")
head(movieData)
```


<table>
<thead><tr><th>MovieId</th><th>UserId</th><th>Rating</th><th>Timestamp</th><th>Movie.Name</th></tr></thead>
<tbody>
	<tr><td>  8                                          </td><td> 3296                                        </td><td>5                                            </td><td>1396981211                                   </td><td>Edison Kinetoscopic Record of a Sneeze (1894)</td></tr>
	<tr><td> 91                                          </td><td> 4879                                        </td><td>6                                            </td><td>1385233195                                   </td><td>Le manoir du diable (1896)                   </td></tr>
	<tr><td>417                                          </td><td>15463                                        </td><td>7                                            </td><td>1392806422                                   </td><td>Le voyage dans la lune (1902)                </td></tr>
	<tr><td>628                                          </td><td>19326                                        </td><td>4                                            </td><td>1385729728                                   </td><td>The  s of Dollie (1908)                      </td></tr>
	<tr><td>628                                          </td><td> 8178                                        </td><td>5                                            </td><td>1381446481                                   </td><td>The  s of Dollie (1908)                      </td></tr>
	<tr><td>833                                          </td><td>19326                                        </td><td>3                                            </td><td>1385738847                                   </td><td>The Country Doctor (1909)                    </td></tr>
</tbody>
</table>




```R
# What is the average rating for each movie?
# install.packages("dplyr")
library(dplyr)

select(movieData, MovieId, Movie.Name, Rating) %>%
  group_by(Movie.Name) %>%
  summarize("MeanRating" = mean(Rating)) %>%
  arrange(desc(MeanRating))
```

    Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in grepl("^\\s*$", values):
    “input string 1 is invalid in this locale”Warning message in grepl("^\\s*$", values):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”Warning message in FUN(X[[i]], ...):
    “input string 1 is invalid in this locale”ERROR while rich displaying an object: Error in gsub(" &\\", "\\", r, fixed = TRUE): input string 1 is invalid in this locale
    
    Traceback:
    1. FUN(X[[i]], ...)
    2. tryCatch(withCallingHandlers({
     .     if (!mime %in% names(repr::mime2repr)) 
     .         stop("No repr_* for mimetype ", mime, " in repr::mime2repr")
     .     rpr <- repr::mime2repr[[mime]](obj)
     .     if (is.null(rpr)) 
     .         return(NULL)
     .     prepare_content(is.raw(rpr), rpr)
     . }, error = error_handler), error = outer_handler)
    3. tryCatchList(expr, classes, parentenv, handlers)
    4. tryCatchOne(expr, names, parentenv, handlers[[1L]])
    5. doTryCatch(return(expr), name, parentenv, handler)
    6. withCallingHandlers({
     .     if (!mime %in% names(repr::mime2repr)) 
     .         stop("No repr_* for mimetype ", mime, " in repr::mime2repr")
     .     rpr <- repr::mime2repr[[mime]](obj)
     .     if (is.null(rpr)) 
     .         return(NULL)
     .     prepare_content(is.raw(rpr), rpr)
     . }, error = error_handler)
    7. repr::mime2repr[[mime]](obj)
    8. repr_latex.data.frame(obj)
    9. gsub(" &\\", "\\", r, fixed = TRUE)
    Warning message in grepl("<html.*>", data[["text/html"]], ignore.case = TRUE):
    “input string 1 is invalid in this locale”


<table>
<thead><tr><th>Movie.Name</th><th>MeanRating</th></tr></thead>
<tbody>
	<tr><td>  Story (2013)                           </td><td>10                                       </td></tr>
	<tr><td>-1945                                    </td><td>10                                       </td></tr>
	<tr><td>? nos amours. (1983)                     </td><td>10                                       </td></tr>
	<tr><td>12 OClock Boys (2013)Biography           </td><td>10                                       </td></tr>
	<tr><td>13 Ghosts (1960)                         </td><td>10                                       </td></tr>
	<tr><td>13 Rue Madeleine (1947)                  </td><td>10                                       </td></tr>
	<tr><td>1492 Conquest of Paradise (1992)Biography</td><td>10                                       </td></tr>
	<tr><td>17 Seconds (2013)                        </td><td>10                                       </td></tr>
	<tr><td>2 Kings (2011)                           </td><td>10                                       </td></tr>
	<tr><td>2by4 (1998)                              </td><td>10                                       </td></tr>
	<tr><td>44 (2007)                                </td><td>10                                       </td></tr>
	<tr><td>46-okunen no koi (2006)                  </td><td>10                                       </td></tr>
	<tr><td>6 Month Rule (2011)                      </td><td>10                                       </td></tr>
	<tr><td>846 (2011)                               </td><td>10                                       </td></tr>
	<tr><td>903 (2012)                               </td><td>10                                       </td></tr>
	<tr><td>A Decade Under the Influence (2003)      </td><td>10                                       </td></tr>
	<tr><td>A Different Tree (2013)                  </td><td>10                                       </td></tr>
	<tr><td>A Dirty Shame (2004)                     </td><td>10                                       </td></tr>
	<tr><td>A Good Day to Die (2010)BiographyNews    </td><td>10                                       </td></tr>
	<tr><td>A Man Betrayed (1941)                    </td><td>10                                       </td></tr>
	<tr><td>A Most Wanted Man (2014)                 </td><td>10                                       </td></tr>
	<tr><td>A Passage to India (1984)                </td><td>10                                       </td></tr>
	<tr><td>A Patch of Blue (1965)                   </td><td>10                                       </td></tr>
	<tr><td>A Soldiers Story (1984)                  </td><td>10                                       </td></tr>
	<tr><td>A Tale of Two Pastries (2012)            </td><td>10                                       </td></tr>
	<tr><td>A Terrorist Ate My Brain (2006)          </td><td>10                                       </td></tr>
	<tr><td>A Wonderful Moment (2013)                </td><td>10                                       </td></tr>
	<tr><td>A Year with Armin Van Buuren (2012)      </td><td>10                                       </td></tr>
	<tr><td>A.B.S (2012)                             </td><td>10                                       </td></tr>
	<tr><td>A.R.O.G (2008)                           </td><td>10                                       </td></tr>
	<tr><td>...</td><td>...</td></tr>
	<tr><td>The Giant Spider Invasion (1975)        </td><td>1                                       </td></tr>
	<tr><td>The Guillotines (2012)                  </td><td>1                                       </td></tr>
	<tr><td>The Kane Files Life of Trial (2010)     </td><td>1                                       </td></tr>
	<tr><td>The Last Broadcast (1998)               </td><td>1                                       </td></tr>
	<tr><td>The Last Leprechaun (1998)              </td><td>1                                       </td></tr>
	<tr><td>The Master of Disguise (2002)           </td><td>1                                       </td></tr>
	<tr><td>The Mighty Macs (2009)                  </td><td>1                                       </td></tr>
	<tr><td>The Mistress of Spices (2005)           </td><td>1                                       </td></tr>
	<tr><td>The New Year (2010)                     </td><td>1                                       </td></tr>
	<tr><td>The Nutcracker in 3D (2009)             </td><td>1                                       </td></tr>
	<tr><td>The Oregonian (2011)                    </td><td>1                                       </td></tr>
	<tr><td>The Party at Kitty and Studs (1970)Adult</td><td>1                                       </td></tr>
	<tr><td>The Ringer (2005)                       </td><td>1                                       </td></tr>
	<tr><td>The Secret Village (2013)               </td><td>1                                       </td></tr>
	<tr><td>The Taking (2013)                       </td><td>1                                       </td></tr>
	<tr><td>The Tree (2010)                         </td><td>1                                       </td></tr>
	<tr><td>The Underground   Movie (1999)          </td><td>1                                       </td></tr>
	<tr><td>Total Force (1997)                      </td><td>1                                       </td></tr>
	<tr><td>Tre solar (2004)                        </td><td>1                                       </td></tr>
	<tr><td>Treachery (2013)                        </td><td>1                                       </td></tr>
	<tr><td>Un altro pianeta (2008)                 </td><td>1                                       </td></tr>
	<tr><td>Viva Cuba (2005)                        </td><td>1                                       </td></tr>
	<tr><td>Wild Seven (2006)                       </td><td>1                                       </td></tr>
	<tr><td>Zapata - El sue&lt;a4&gt;o del h&lt;82&gt;roe (2004) &lt;/a4&gt;</td><td>1                                        </td></tr>
	<tr><td>Zindagi 50 50 (2013)                    </td><td>1                                       </td></tr>
	<tr><td>Zombex (2013)                           </td><td>1                                       </td></tr>
	<tr><td>Zombie Nation (2004)                    </td><td>1                                       </td></tr>
	<tr><td>Zombie Undead (2010)                    </td><td>1                                       </td></tr>
	<tr><td>&lt;ad&gt;Vivan los novios (1970)                &lt;/ad&gt;</td><td>1                                          </td></tr>
	<tr><td>El rey de Najayo (2012)                 </td><td>0                                       </td></tr>
</tbody>
</table>




```R
# Install the lubridate and xts packages
install.packages("lubridate")
library(lubridate)

install.packages("xts")
library(xts)
```

    Installing package into ‘/home/nbuser/R’
    (as ‘lib’ is unspecified)
    also installing the dependency ‘stringr’
    
    Warning message in install.packages("lubridate"):
    “installation of package ‘lubridate’ had non-zero exit status”
    Attaching package: ‘lubridate’
    
    The following object is masked from ‘package:base’:
    
        date
    
    Installing package into ‘/home/nbuser/R’
    (as ‘lib’ is unspecified)
    Loading required package: zoo
    
    Attaching package: ‘zoo’
    
    The following objects are masked from ‘package:base’:
    
        as.Date, as.Date.numeric
    
    
    Attaching package: ‘xts’
    
    The following objects are masked from ‘package:dplyr’:
    
        first, last
    
    The following object is masked from ‘package:AzureML’:
    
        endpoints
    



```R
# Step 1: Convert the dataset into an xts object (the Timestamp is a POSIXct datetime)
xtsMovieData <- xts(movieData[c("MovieId", "UserId", "Rating", "Movie.Name")], order.by=as.POSIXct(movieData$Timestamp, origin = "1970-01-01"))
head(xtsMovieData)
```


                        MovieId   UserId  Rating
    2013-02-28 14:38:27 "2171847" "18507" " 6"  
    2013-02-28 14:43:44 " 444778" "16458" " 8"  
    2013-02-28 14:47:18 "1411238" " 3136" " 6"  
    2013-02-28 14:58:23 "1496422" "21655" " 7"  
    2013-02-28 15:00:53 " 118799" "16777" " 5"  
    2013-02-28 15:04:39 " 338013" "16777" " 4"  
                        Movie.Name                                    
    2013-02-28 14:38:27 "Dead Mine (2012) "                           
    2013-02-28 14:43:44 "Mah nakorn (2004) "                          
    2013-02-28 14:47:18 "No Strings Attached (2011)"                  
    2013-02-28 14:58:23 "The Paperboy (2012)"                         
    2013-02-28 15:00:53 "La vita \x8a bella (1997) "                
    2013-02-28 15:04:39 "Eternal Sunshine of the Spotless Mind (2004)"



```R
# Step 2: Count the number of ratings posted per day
ratingsPerDay <- apply.daily(xtsMovieData, function(data) { nrow(data$Rating) })
head(ratingsPerDay)

```


                        [,1]
    2013-02-28 23:55:41  245
    2013-03-01 23:53:21  509
    2013-03-02 23:55:52  672
    2013-03-03 23:58:43  905
    2013-03-04 23:58:42  570
    2013-03-05 23:58:38  433



```R
# Install the broom and ggplot2 packages
install.packages("broom")
library(broom)

install.packages("ggplot2")
library(ggplot2)
```

    Installing package into ‘/home/nbuser/R’
    (as ‘lib’ is unspecified)
    also installing the dependency ‘generics’
    
    Installing package into ‘/home/nbuser/R’
    (as ‘lib’ is unspecified)
    Warning message in install.packages("ggplot2"):
    “installation of package ‘ggplot2’ had non-zero exit status”


```R
# Step 3: Graph the results
graphData <- tidy(ratingsPerDay)
graphData$index <- as.POSIXct(graphData$index,  origin="1970-01-01")

options(repr.plot.width=15, repr.plot.height=4)
ggplot(graphData, aes(x = index, y = value)) +
  ggtitle("Ratings Posted Per Day") +
  xlab("Date") +
  ylab("Number of Ratings") +
  geom_line(color = "blue")

```


![png](output_8_0.png)

